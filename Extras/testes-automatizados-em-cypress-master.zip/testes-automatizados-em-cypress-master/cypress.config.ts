import { defineConfig } from 'cypress'

export default defineConfig({
  projectId: 'vxta51',
  e2e: {
    baseUrl: 'https://mais.ifmg.edu.br/maisifmg',
    viewportWidth: 1440,
    viewportHeight: 900,
    defaultCommandTimeout: 20000,
    pageLoadTimeout: 30000,
    requestTimeout: 20000,
    responseTimeout: 30000,
    video: true,
    screenshotOnRunFailure: true,
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
})