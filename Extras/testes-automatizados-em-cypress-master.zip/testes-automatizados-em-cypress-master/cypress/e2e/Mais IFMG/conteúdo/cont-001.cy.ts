describe('Teste de Conteúdo - Mais IFMG', () => {
    beforeEach(() => {
        cy.clearSession();
        cy.visitHomePage();
        cy.handleUncaughtExceptions();
    });  

    it('CONT-001: Acesso a conteúdo em vídeo do curso', () => {
        cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
        cy.get('body').should('be.visible');
        cy.title().should('include', '+IFMG');

        // Chama o comando de login com parâmetros
        cy.login('deisilani', 'Tcc123@2024');

        // Clica no botão engrenagem
        cy.get('.flaticon-settings').click();

        // Clica na opção "Painel"
        cy.get('.list-group > [href="https://mais.ifmg.edu.br/maisifmg/my/"]').click();

        // Passa o mouse sobre o elemento específico
        cy.get('[role="listitem"][data-course-id="141"] > .thumb > .img-whp')
            .trigger('mouseover');

        // Aguarda um breve momento para garantir que o mouseover funcione
        cy.wait(500);

        // Força a visibilidade do botão "View" e clica nele
        cy.get('[data-region="view-content"] .mcc_view')
            .invoke('show')
            .click({ force: true });
        
        // Clica sobre o vídeo    
        cy.get('#module-4038 > :nth-child(1) > .mod-indent-outer > :nth-child(2) > .activityinstance > .aalink').click();

        // Clica no botão "Tocar Vídeo" usando a classe do botão
        cy.get('.vjs-big-play-button').click();

        cy.contains('Obs.: após iniciar o vídeo selecione, no canto inferior direito, a opção "tela cheia".')
        .should('be.visible');
    });
});