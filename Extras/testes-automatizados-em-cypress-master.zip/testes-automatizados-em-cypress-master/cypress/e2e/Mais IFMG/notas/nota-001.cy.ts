describe('Teste de Livro de notas - Mais IFMG', () => {
    beforeEach(() => {
        cy.clearSession();
        cy.visitHomePage();
        cy.handleUncaughtExceptions();
    });  

    it('NOTA-001: Visualizar nota de cursos cursados ou cursando', () => {
        cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
        cy.get('body').should('be.visible');
        cy.title().should('include', '+IFMG');

        // Chama o comando de login com parâmetros
        cy.login('deisilani', 'Tcc123@2024');

        // Abre opções do perfil
        cy.get('.btn > .rounded-circle').click();

        // Clica na opção Painel
        cy.get('.user_setting_content > [href="https://mais.ifmg.edu.br/maisifmg/my/"]').click();

        // Clica na opção Livro de Notas
        cy.get(':nth-child(4) > .ff_one > .ff_icon').click();

        // Aguarda o carregamento do conteúdo e verifica se a frase "Cursos que estou cursando" está presente
        cy.contains('Cursos que estou cursando').should('be.visible');
    });
});
