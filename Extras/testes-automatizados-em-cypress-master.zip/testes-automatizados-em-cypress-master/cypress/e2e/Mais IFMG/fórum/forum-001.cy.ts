describe('Teste de Fórum - Mais IFMG', () => {
  beforeEach(() => {
    cy.clearSession();
    cy.visitHomePage();
    cy.handleUncaughtExceptions();
  });

  it('FORUM-001: Criação de nova discussão no fórum', () => {
    cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
    cy.get('body').should('be.visible');
    cy.title().should('include', '+IFMG');

    // Chama o comando de login com parâmetros
    cy.login('deisilani', 'Tcc123@2024');

    // Clica no botão engrenagem
    cy.get('.flaticon-settings').click();

    // Clica na opção "Painel"
    cy.get('.list-group > [href="https://mais.ifmg.edu.br/maisifmg/my/"]').click();

    // Seleciona o primeiro elemento específico e clica
    cy.get('div[data-course-id="117"]').find('a.mcc_view').first().click({ force: true });

    // Encontra a palavra "Fórum “Bem vindo(a) ao curso! Apresente-se”" e clica sobre ela
    cy.contains('span.instancename', 'Fórum “Bem vindo(a) ao curso! Apresente-se”')
      .should('be.visible')
      .click();

    // Clica no link específico para responder ao fórum
    cy.get('[href="https://mais.ifmg.edu.br/maisifmg/mod/forum/post.php?reply=7310#mformforum"]')
      .should('be.visible')
      .click();

    // Aguarda o campo de formulário abrir e preenche o campo com todas as informações fornecidas
    cy.get('span > .form-control')
      .should('be.visible')
      .type('Nome: Deisilani, Idade: 28, Escolaridade: Cursando ensino superior, Profissão: QA, Por que está fazendo o curso? Para adquirir conhecimento');

    // Envia o formulário
    cy.get(':nth-child(2) > .btn-primary').click();
  });
});
