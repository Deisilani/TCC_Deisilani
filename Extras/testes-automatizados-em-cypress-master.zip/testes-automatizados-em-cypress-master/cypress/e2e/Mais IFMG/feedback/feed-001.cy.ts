describe('Teste de Feedback - Mais IFMG', () => {
  beforeEach(() => {
    // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
    cy.clearSession();
    cy.visitHomePage();
    cy.handleUncaughtExceptions();
  });

  it('FEED-001: Envio de feedback do curso', () => {
    // Verifica se a URL está correta
    cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

    // Verifica se elementos importantes da página estão visíveis
    cy.get('body').should('be.visible');

    // Verifica se o título da página contém "+IFMG"
    cy.title().should('include', '+IFMG');

    // Utiliza o comando personalizado para realizar o login
    cy.login('deisilani', 'Tcc123@2024');

    // Clica no botão engrenagem
    cy.get('.flaticon-settings').click();

    // Clica na opção "Painel"
    cy.get('.list-group > [href="https://mais.ifmg.edu.br/maisifmg/my/"]').click();

    // Passa o mouse sobre o elemento específico
    cy.get('[role="listitem"][data-course-id="141"] > .thumb > .img-whp')
      .trigger('mouseover');

    // Aguarda um breve momento para garantir que o mouseover funcione
    cy.wait(500);

    // Força a visibilidade do botão "View" e clica nele
    cy.get('[data-region="view-content"] .mcc_view')
      .invoke('show')
      .click({ force: true });

    // seleciona a quantidade de estrelas, no caso foi 5    
    cy.get('[for="stars-5"]').click();

    // Clica no botão Enviar classificação
    cy.get('#ccn-star-rate > .btn').click();

    // Verifica se o texto Rating complete!
    cy.contains('Rating complete!').should('be.visible');

  });
});