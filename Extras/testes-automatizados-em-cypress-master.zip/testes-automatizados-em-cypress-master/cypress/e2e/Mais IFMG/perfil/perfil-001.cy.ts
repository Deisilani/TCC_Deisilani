describe('Teste de Perfil - Mais IFMG', () => {
    beforeEach(() => {
        cy.clearSession();
        cy.visitHomePage();
        cy.handleUncaughtExceptions();
    });  

    it('PERF-001: Atualização de dados do perfil', () => {
        cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
        cy.get('body').should('be.visible');
        cy.title().should('include', '+IFMG');

        // Chama o comando de login com parâmetros
        cy.login('deisilani', 'Tcc123@2024');

        // Abre opções do perfil
        cy.get('.btn > .rounded-circle').click();

        // Clica na opção Perfil
        cy.get('.user_setting_content > [href="https://mais.ifmg.edu.br/maisifmg/user/profile.php?id=202843"]').click();

        // Clica no painel "Detalhes do usuário"
        cy.get(':nth-child(1) > #accordion > .panel > .panel-heading > .panel-title > .accordion-toggle').click();

        // Aguarda o painel abrir e clica em "Modificar perfil"
        cy.get('#panel-contact > .panel-body > .my_resume_eduarea > .style-link > .edu_stats > a')
          .should('be.visible')
          .click();

        // Inserir cidade/município
        cy.get('#id_city').type('Campinas SP');

        cy.get('#id_profile_field_rendafamiliarmensal').select('De 1 a 3 salários mínimos (de R$ 1.412,01 a R$ 4.236,00).');

        // Clica no botão Atualizar o perfil
        cy.get('#id_submitbutton').click();

        // Mostra o erro "Please fill the Cadastro de Pessoas Físicas (CPF) field. It cannot be left empty based on the value you selected here."
        // mesmo o campo sendo preenchido por um CPF válido. Teste não passou.

    });
});