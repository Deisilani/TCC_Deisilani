describe('Teste de Requerimento de registro do certificado - Mais IFMG', () => {
    beforeEach(() => {
        // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
        cy.clearSession();
        cy.visitHomePage();
        cy.handleUncaughtExceptions();
    });

    it('deve solicitar o requerimento de registro do certificado', () => {
        // Verifica se a URL está correta
        cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

        // Verifica se elementos importantes da página estão visíveis
        cy.get('body').should('be.visible');

        // Verifica se o título da página contém "+IFMG"
        cy.title().should('include', '+IFMG');

        // Utiliza o comando personalizado para realizar o login
        cy.login('deisilani', 'Tcc123@2024');

        // Aguarda e verifica se o curso específico está visível antes de clicar
        cy.get(':nth-child(6) > .img_hvr_box').click();  

        // Clica sobre o curso
        cy.get('[href="https://mais.ifmg.edu.br/maisifmg/course/view.php?id=141"] > h5').click();

        // Clica sobre a opção de requerer o certificado
        cy.get('#module-4049 > :nth-child(1) > .mod-indent-outer > :nth-child(2) > .activityinstance > .aalink > .instancename').click();

        // Deve clicar no texto "Continuar a última tentativa"
        cy.contains('Continuar a última tentativa').click();

        // Encontra o texto "Nome completo"
        cy.contains('Nome completo').should('be.visible');

        // Clica no campo para ativá-lo e garantir que ele esteja focado
        cy.get('#q384069\\:1_answer_ideditable')
            .should('be.visible') // Verifica se o campo está visível
            .focus()              // Foca no campo para garantir que ele está pronto para receber texto
            .clear()              // Limpa qualquer conteúdo anterior
            .type('Deisilani Nunes Nascimento'); // Preenche o campo com o nome

        // Encontra o texto "E-mail para contato" e preenche
        cy.contains('E-mail para contato:').should('be.visible');
        cy.get('#q384069\\:2_answer_ideditable')
            .focus()
            .clear()
            .type('deisilani.nunes@aluno.ifsp.edu.br');

        // Encontra o texto "Estado:" e clica sobre "SP"
        cy.contains('Estado:').should('be.visible');
        cy.get('#q384069_3_p1').select('SP'); // Usando cy.select() para selecionar a opção

        // Encontra o texto "Sexo:" e clica sobre a opção correta
        cy.contains('Sexo:').should('be.visible');
        cy.get('#q384069\\:4_answer1').click();

        // Encontra o texto "Nacionalidade" e clica sobre a opção correta
        cy.contains('Nacionalidade:').should('be.visible');
        cy.get('#q384069\\:5_answer0').check();

        // Encontra o texto "Escolaridade" e clica sobre a opção correta
        cy.contains('Escolaridade').should('be.visible');
        cy.get('#q384069\\:6_answer1').click();

        // Encontra o texto sobre os rendimentos e clica sobre a opção correta
        cy.contains('Some os rendimentos de todos os integrantes do núcleo familiar e dividida pelo número de pessoas, incluindo os menores de idade e adultos sem renda:').should('be.visible');
        cy.get('#q384069\\:7_answer1').click();

        // Clica sobre o botão finalizar tentativa
        cy.contains('Finalizar tentativa ...')  
            .should('be.visible') 
            .click();

        // Clica sobre o botão Enviar tudo e terminar
        cy.contains('Enviar tudo e terminar')  
            .should('be.visible') 
            .click();

        // Clica sobre o botão que confirma Enviar tudo e terminar
        // cy.get('#id_yuiconfirmyes-yui_3_17_2_2_1732161570663_8')
    });
});
