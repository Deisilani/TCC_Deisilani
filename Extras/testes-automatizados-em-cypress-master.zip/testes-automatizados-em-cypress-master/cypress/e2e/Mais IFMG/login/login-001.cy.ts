describe('Teste de Login com credenciais válidas - Mais IFMG', () => {
  beforeEach(() => {
      // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
      cy.clearSession();
      cy.visitHomePage();
      cy.handleUncaughtExceptions();
  });

  it('MAISIFMG-001: deve acessar a página inicial do Mais IFMG', () => {
      // Verifica se a URL está correta
      cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

      // Verifica se elementos importantes da página estão visíveis
      cy.get('body').should('be.visible');

      // Verifica se o título da página contém "+IFMG"
      cy.title().should('include', '+IFMG');

      // Utiliza o comando personalizado para realizar o login
      cy.login('deisilani', 'Tcc123@2024');
  });
});
