describe('Teste para recuperar senha - Mais IFMG', () => {
    beforeEach(() => {
      // Limpa cookies e localStorage para garantir que está deslogado
      cy.clearCookies();
      cy.clearLocalStorage();
      
      // Visita a página inicial do Mais IFMG antes de cada teste
      cy.visit('https://mais.ifmg.edu.br/maisifmg/');
    });
  
    it('MAISIFMG-003: deve ser possível solicitar a troca de senha', () => {
      // Clica no botão login
      cy.get('.dn-lg')
        .should('be.visible')
        .click();
  
      // Espera o modal ficar visível verificando a classe show do Bootstrap
      cy.get('#exampleModalCenter').should('have.class', 'show');
  
      // Clica no botão Perdeu a senha
      cy.get('.tdu')
        .should('be.visible')
        .click();
  
      // Aguarda a página de recuperação carregar
      cy.wait(1000);
  
      // Insere o nome de usuário no campo
      cy.get('#id_username')
        .should('be.visible')
        .type('deisilani');
  
      // Clica no botão Buscar
      cy.get('#id_submitbuttonusername')
        .should('be.visible')
        .click();
  
      // Aguarda a resposta do servidor
      cy.wait(2000);
  
      // Verifica se a mensagem de confirmação aparece
      cy.contains('Se o nome de usuário ou o e-mail estiverem corretos, um e-mail deve ter sido enviado a você.')
        .should('be.visible');
  
      // Clica no botão Continuar
      cy.contains('button', 'Continuar')
        .should('be.visible')
        .click();
    });
  });