describe('Teste de Login com senha inválida - Mais IFMG', () => {
  beforeEach(() => {
      // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
      cy.clearSession();
      cy.visitHomePage();
      cy.handleUncaughtExceptions();
  });

  it('MAISIFMG-002: deve exibir mensagem de erro ao tentar login com senha inválida', () => {
      // Verifica se a URL está correta
      cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

      // Verifica se elementos importantes da página estão visíveis
      cy.get('body').should('be.visible');

      // Verifica se o título da página contém "+IFMG"
      cy.title().should('include', '+IFMG');

      // Clica no botão login
      cy.get('.dn-lg').click();

      // Espera o modal ficar visível verificando a classe show do Bootstrap
      cy.get('#exampleModalCenter').should('have.class', 'show');

      // Insere usuário
      cy.get('#login_username').type('deisilani');

      // Insere senha inválida
      cy.get('#login_password').type('Flash@24');

      // Clica em Acessar
      cy.get('#login > .btn').click();

      // Verifica se a mensagem de erro aparece
      cy.get('.alert-danger')
          .should('be.visible')
          .and('contain', 'Nome de usuário ou senha errados. Por favor tente outra vez.');
  });
});
