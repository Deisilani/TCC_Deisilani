describe('Teste de Livro de notas - Mais IFMG', () => {
    beforeEach(() => {
        cy.clearSession();
        cy.visitHomePage();
        cy.handleUncaughtExceptions();
    });  

    it('NOTA-001: Visualizar nota de cursos cursados ou cursando', () => {
        cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
        cy.get('body').should('be.visible');
        cy.title().should('include', '+IFMG');

        // Chama o comando de login com parâmetros
        cy.login('deisilani', 'Tcc123@2024');

        // Abre opções do perfil
        cy.get('.btn > .rounded-circle').click();

        // Clica em Sair
        cy.get('.dropdown-item').contains('Sair').click();
    });
});
