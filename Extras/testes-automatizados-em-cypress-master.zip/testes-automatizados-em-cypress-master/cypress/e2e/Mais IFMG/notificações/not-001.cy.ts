describe('Teste de Notificação - Mais IFMG', () => {
  beforeEach(() => {
    cy.clearSession();
    cy.visitHomePage();
    cy.handleUncaughtExceptions();
  });

  it('NOT-001: Configuração de preferências de notificação', () => {
    cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');
    cy.get('body').should('be.visible');
    cy.title().should('include', '+IFMG');

    // Chama o comando de login com parâmetros
    cy.login('deisilani', 'Tcc123@2024');

    // Abre opções do perfil
    cy.get('.btn > .rounded-circle').click();

    // Clica na opção Painel
    cy.get('.user_setting_content > [href="https://mais.ifmg.edu.br/maisifmg/my/"]').click();

    // Clica em Preferências
    cy.get('.dashbord_nav_list > ul > :nth-child(5) > a').click();

    // Clica em Preferências de notificação
    cy.get('.card-text > :nth-child(9) > a').click();

    // Desabilita notificações de tarefas por e-mail
    const quickMailRow = cy.get('tr').contains('Mensagem Quickmail').parent();
    const mailColumn = quickMailRow.find('[data-processor-name="email"]');
    const onlineCollumn = mailColumn.find('div.row-fluid').children().eq(0);

    const aaaa = onlineCollumn.find('.preference-state-status-container');

    onlineCollumn.find('.off-text').click();
    aaaa.parent().find('.on-text').click();

  });
});