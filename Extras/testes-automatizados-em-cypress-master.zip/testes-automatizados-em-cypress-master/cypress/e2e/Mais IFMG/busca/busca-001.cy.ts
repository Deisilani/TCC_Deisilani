describe('Teste de Busca - Mais IFMG', () => {
  beforeEach(() => {
    // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
    cy.clearSession();
    cy.visitHomePage();
    cy.handleUncaughtExceptions();
  });

  it('BUSCA-001: Busca de cursos por palavra-chave', () => {
    // Verifica se a URL está correta
    cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

    // Verifica se elementos importantes da página estão visíveis
    cy.get('body').should('be.visible');

    // Verifica se o título da página contém "+IFMG"
    cy.title().should('include', '+IFMG');

    // Utiliza o comando personalizado para realizar o login
    cy.login('deisilani', 'Tcc123@2024');

    // Clica na busca
    cy.get('#search-button > .flaticon-magnifying-glass').click();

    // Digita a palavra da busca
    cy.get('.ccn-mk-fullscreen-searchform > fieldset > #searchform_search')
      .type('java');

    // Clica no botão da lupa para buscar
    cy.get('#searchform_button').click();

    // Verifica se o texto "Busca global" está presente na página
    cy.contains('Busca global').should('be.visible');
  });
});
