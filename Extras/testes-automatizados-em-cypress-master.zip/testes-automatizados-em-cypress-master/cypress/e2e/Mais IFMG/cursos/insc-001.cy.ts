describe('Teste de Inscrição em um curso - Mais IFMG', () => {
  beforeEach(() => {
      // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
      cy.clearSession();
      cy.visitHomePage();
      cy.handleUncaughtExceptions();
  });

  it('MAISIFMG-001: deve acessar a página inicial e realizar inscrição em um curso', () => {
      // Verifica se a URL está correta
      cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

      // Verifica se elementos importantes da página estão visíveis
      cy.get('body').should('be.visible');

      // Verifica se o título da página contém "+IFMG"
      cy.title().should('include', '+IFMG');

      // Utiliza o comando personalizado para realizar o login
      cy.login('deisilani', 'Tcc123@2024');

      // Aguarda e verifica se o curso específico está visível antes de clicar
      cy.get(':nth-child(6) > .img_hvr_box').click();

       // Clica no link do curso específico
      cy.get('[href="https://mais.ifmg.edu.br/maisifmg/course/view.php?id=142"] > h5').click();

      // Aguarda e verifica se o botão "Inscreva-me" está visível e habilitado antes de clicar
      cy.get('#id_submitbutton')
          .should('be.visible')
          .should('not.be.disabled')
          .should('have.value', 'Inscreva-me')
         .click();

      // Verifica se a mensagem de sucesso de inscrição está visível
      cy.contains('Você está inscrito no curso.').should('be.visible');
  });
});
