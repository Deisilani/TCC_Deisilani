describe('Teste de Navegação', () => {
  beforeEach(() => {
      // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
      cy.clearSession();
      cy.visitHomePage();
      cy.handleUncaughtExceptions();
  });

  it('NAV-001: deve navegar entre módulos do curso', () => {
      // Verifica se a URL está correta
      cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

      // Verifica se elementos importantes da página estão visíveis
      cy.get('body').should('be.visible');

      // Verifica se o título da página contém "+IFMG"
      cy.title().should('include', '+IFMG');

      // Utiliza o comando personalizado para realizar o login
      cy.login('deisilani', 'Tcc123@2024');

      // Aguarda e verifica se o curso específico está visível antes de clicar
      cy.get(':nth-child(6) > .img_hvr_box').click();
      
      // Clica no curso específico
      cy.get('[href="https://mais.ifmg.edu.br/maisifmg/course/view.php?id=141"] > h5').click();

      // Verifica o texto "Progresso de Conclusão"
      cy.get('#instance-47756-header')
          .should('be.visible')
          .should('contain', 'Progresso de Conclusão');

      // Passa o mouse sobre a barra de progresso específica do curso
      cy.get('[data-info-ref="progressBarInfo47756-202843-4040"]')
          .should('be.visible')
          .trigger('mouseover');

      // Clica no dropdown Semana 1
      cy.get('#section-1 > #accordion > .panel > .panel-heading > .panel-title > .accordion-toggle').click();
      
      // Clica no dropdown Semana 2
      cy.get('#section-2 > #accordion > .panel > .panel-heading > .panel-title > .accordion-toggle').click();

      // Clica no dropdown Semana 3
      cy.get('#section-3 > #accordion > .panel > .panel-heading > .panel-title > .accordion-toggle').click();

      // Clica no dropdown Semana 4
      cy.get('#section-4 > #accordion > .panel > .panel-heading > .panel-title > .accordion-toggle').click();
  });
});
