describe('Teste de Suporte - Mais IFMG', () => {
  beforeEach(() => {
    // Utiliza os comandos personalizados para limpar sessão, visitar a página inicial e configurar exceções
    cy.clearSession();
    cy.visitHomePage();
    cy.handleUncaughtExceptions();
  });

  it('SUP-001: Criação de ticket de suporte', () => {
    // Verifica se a URL está correta
    cy.url().should('eq', 'https://mais.ifmg.edu.br/maisifmg/');

    // Verifica se elementos importantes da página estão visíveis
    cy.get('body').should('be.visible');

    // Verifica se o título da página contém "+IFMG"
    cy.title().should('include', '+IFMG');

    // Utiliza o comando personalizado para realizar o login
    cy.login('deisilani', 'Tcc123@2024');

    // Clica para acessar tela do suporte
    cy.get('.footer_apps_widget > div > a').click();

    cy.contains('Entre em contato').should('be.visible');

    cy.get('#name')
      .should('be.visible')
      .type('Deisilani nunes');

      cy.get('#email')
        .should('be.visible')
        .type('deisilani.nunes@aluno.ifsp.edu.br');

      cy.get('#message')
        .should('be.visible')
        .type('olá, gostaria de quando vai abrir inscrição para novos cursos?');

      cy.get('#submit').click();
  });
});
