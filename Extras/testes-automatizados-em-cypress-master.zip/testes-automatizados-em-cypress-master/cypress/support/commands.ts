// cypress/support/commands.ts

// Limpa cookies e localStorage
Cypress.Commands.add('clearSession', () => {
  cy.clearCookies();
  cy.clearLocalStorage();
});

// Visita a página inicial do Mais IFMG
Cypress.Commands.add('visitHomePage', () => {
  cy.visit('https://mais.ifmg.edu.br/maisifmg/');
});

// Configura o tratamento de exceções não tratadas
Cypress.Commands.add('handleUncaughtExceptions', () => {
  Cypress.on('uncaught:exception', (err, runnable) => {
    // retornando false previne que o Cypress falhe o teste
    return false;
  });
});

// Realiza login na aplicação
Cypress.Commands.add('login', (username: string, password: string) => {
  cy.visit('https://mais.ifmg.edu.br/maisifmg/login/index.php')

  // Insere o usuário
  cy.get('#username')
    .clear()
    .focus()
    .type(username);

  // Insere senha
  cy.get('#password')
    .clear()
    .focus()
    .type(password);

  // Aguarda um breve momento para garantir que o texto foi inserido corretamente
  cy.wait(500);

  // Clica em Acessar
  cy.get('#loginbtn').click();
  cy.wait(2000);
});
