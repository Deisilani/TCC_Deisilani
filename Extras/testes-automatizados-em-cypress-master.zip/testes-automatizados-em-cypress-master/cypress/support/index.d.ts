// cypress/support/index.d.ts

/// <reference types="cypress" />

declare namespace Cypress {
    interface Chainable<Subject = any> {
      clearSession(): Chainable<void>;
      visitHomePage(): Chainable<void>;
      handleUncaughtExceptions(): Chainable<void>;
      login(username: string, password: string): Chainable<void>;
    }
  }
  